Various Macintosh-specific files have been moved to this directory to avoid clutter.  You can move stuff back for easier compilation.

These files are NOT up to date and are not recommended for use unless the SDL port cannot be made to work on your system, or you know what you are doing.
