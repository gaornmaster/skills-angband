Various UNIX-specific files have been moved to this directory to avoid clutter.  Move stuff back for easier compilation.

These ports are not fully up to date.  Be sure to read the compiling docs.
